import { sql } from "drizzle-orm";
import { pgTable, text, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Artwork analysis schemas
export const artworkAnalysisSchema = z.object({
  title: z.string(),
  artist: z.string(),
  year: z.string().optional(),
  style: z.string().optional(),
  medium: z.string().optional(),
  artistBio: z.string().optional(),
  historicalContext: z.string().optional(),
  trivia: z.string().optional(),
  imageUrl: z.string().optional(),
});

export const similarArtworkSchema = z.object({
  id: z.string(),
  title: z.string(),
  artist: z.string(),
  imageUrl: z.string(),
  similarity: z.number(),
});

export const chatMessageSchema = z.object({
  prompt: z.string(),
  artworkContext: z.string().optional(),
});

export type ArtworkAnalysis = z.infer<typeof artworkAnalysisSchema>;
export type SimilarArtwork = z.infer<typeof similarArtworkSchema>;
export type ChatMessage = z.infer<typeof chatMessageSchema>;
