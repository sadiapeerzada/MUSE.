import { useState } from "react";
import UploadZone from "@/components/UploadZone";
import ArtworkDisplay from "@/components/ArtworkDisplay";
import ArtworkInfoPanel from "@/components/ArtworkInfoPanel";
import SimilarArtworksGrid from "@/components/SimilarArtworksGrid";
import ChatInterface from "@/components/ChatInterface";
import ThemeToggle from "@/components/ThemeToggle";
import { Palette } from "lucide-react";
import type { ArtworkAnalysis, SimilarArtwork } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export default function HomePage() {
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [artworkInfo, setArtworkInfo] = useState<ArtworkAnalysis | null>(null);
  const [similarArtworks, setSimilarArtworks] = useState<SimilarArtwork[]>([]);
  const { toast } = useToast();

  const handleImageSelect = async (file: File, preview: string) => {
    setUploadedImage(preview);
    setIsAnalyzing(true);
    
    try {
      const formData = new FormData();
      formData.append("image", file);

      const response = await fetch("/api/analyze-image", {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        throw new Error("Failed to analyze image");
      }

      const data = await response.json();
      setArtworkInfo(data.analysis);
      setSimilarArtworks(data.similarArtworks || []);
    } catch (error) {
      console.error("Error analyzing image:", error);
      toast({
        title: "Analysis Failed",
        description: "Could not analyze the artwork. Please try again.",
        variant: "destructive",
      });
      setUploadedImage(null);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleSimilarArtworkClick = (artwork: SimilarArtwork) => {
    console.log("Navigate to artwork:", artwork.title);
    toast({
      title: artwork.title,
      description: `By ${artwork.artist}`,
    });
  };

  const handleReset = () => {
    setUploadedImage(null);
    setArtworkInfo(null);
    setSimilarArtworks([]);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#FAF9F6] to-white dark:from-[#222222] dark:to-[#1a1a1a]">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/80 dark:bg-[#222222]/80 backdrop-blur-md shadow-sm">
        <div className="container mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Palette className="h-6 w-6 text-primary" />
            <h1 
              className="text-2xl font-display font-bold tracking-tight cursor-pointer hover-elevate rounded-md px-2 -ml-2"
              onClick={handleReset}
              data-testid="link-home"
            >
              MUSE
            </h1>
          </div>
          <ThemeToggle />
        </div>
      </header>

      {/* Main Content */}
      {!uploadedImage ? (
        <UploadZone onImageSelect={handleImageSelect} />
      ) : (
        <div className="flex flex-col lg:flex-row h-[calc(100vh-73px)]">
          {/* Left Panel - Artwork Display */}
          <div className="w-full lg:w-1/2">
            <ArtworkDisplay
              imageUrl={uploadedImage}
              title={artworkInfo?.title || "Analyzing..."}
              artist={artworkInfo?.artist || "Please wait..."}
            />
          </div>

          {/* Right Panel - Info & Chat */}
          <div className="w-full lg:w-1/2 overflow-y-auto">
            <div className="p-6 space-y-6">
              {isAnalyzing ? (
                <div className="flex items-center justify-center py-20">
                  <div className="text-center">
                    <div className="inline-block h-12 w-12 animate-spin rounded-full border-4 border-solid border-primary border-r-transparent mb-6"></div>
                    <p className="text-lg font-display font-light text-[#222222] dark:text-white">MUSE is analyzing this masterpiece...</p>
                  </div>
                </div>
              ) : artworkInfo ? (
                <>
                  <ArtworkInfoPanel info={artworkInfo} />
                  {similarArtworks.length > 0 && (
                    <SimilarArtworksGrid 
                      artworks={similarArtworks} 
                      onArtworkClick={handleSimilarArtworkClick}
                    />
                  )}
                  <ChatInterface 
                    artworkTitle={artworkInfo.title}
                    artworkContext={`Title: ${artworkInfo.title}, Artist: ${artworkInfo.artist}, Style: ${artworkInfo.style || 'Unknown'}`}
                  />
                </>
              ) : null}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
