import SimilarArtworksGrid from "../SimilarArtworksGrid";

export default function SimilarArtworksGridExample() {
  const mockArtworks = [
    {
      id: "1",
      title: "Lady with an Ermine",
      artist: "Leonardo da Vinci",
      imageUrl: "https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?w=400",
      similarity: 92
    },
    {
      id: "2",
      title: "Girl with a Pearl Earring",
      artist: "Johannes Vermeer",
      imageUrl: "https://images.unsplash.com/photo-1577083552431-6e5fd01988ec?w=400",
      similarity: 87
    },
    {
      id: "3",
      title: "Portrait of a Lady",
      artist: "Rogier van der Weyden",
      imageUrl: "https://images.unsplash.com/photo-1578321272176-b7bbc0679853?w=400",
      similarity: 84
    }
  ];

  const handleClick = (artwork: any) => {
    console.log("Artwork clicked:", artwork.title);
  };

  return <SimilarArtworksGrid artworks={mockArtworks} onArtworkClick={handleClick} />;
}
