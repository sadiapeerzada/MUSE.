import ChatInterface from "../ChatInterface";

export default function ChatInterfaceExample() {
  return <ChatInterface artworkTitle="Mona Lisa" />;
}
