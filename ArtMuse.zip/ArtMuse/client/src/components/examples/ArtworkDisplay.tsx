import ArtworkDisplay from "../ArtworkDisplay";

export default function ArtworkDisplayExample() {
  return (
    <div className="h-screen">
      <ArtworkDisplay
        imageUrl="https://images.unsplash.com/photo-1578321272176-b7bbc0679853?w=800"
        title="Mona Lisa"
        artist="Leonardo da Vinci"
      />
    </div>
  );
}
