import UploadZone from "../UploadZone";

export default function UploadZoneExample() {
  const handleImageSelect = (file: File, preview: string) => {
    console.log("Image selected:", file.name, preview.substring(0, 50));
  };

  return <UploadZone onImageSelect={handleImageSelect} />;
}
