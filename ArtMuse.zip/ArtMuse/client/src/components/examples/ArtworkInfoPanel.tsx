import ArtworkInfoPanel from "../ArtworkInfoPanel";

export default function ArtworkInfoPanelExample() {
  const mockInfo = {
    title: "Mona Lisa",
    artist: "Leonardo da Vinci",
    year: "1503-1519",
    style: "Renaissance",
    medium: "Oil on poplar panel",
    artistBio: "Leonardo da Vinci was an Italian polymath of the High Renaissance who was active as a painter, draughtsman, engineer, scientist, theorist, sculptor, and architect.",
    historicalContext: "The Mona Lisa was painted during the Italian Renaissance, a period of great cultural change and achievement that spanned the 14th to the 17th century.",
    trivia: "The Mona Lisa has no visible eyebrows or eyelashes. It was common at this time for genteel women to pluck them out, as they were considered unsightly."
  };

  return <ArtworkInfoPanel info={mockInfo} />;
}
