import { Card } from "@/components/ui/card";

interface SimilarArtwork {
  id: string;
  title: string;
  artist: string;
  imageUrl: string;
  similarity: number;
}

interface SimilarArtworksGridProps {
  artworks: SimilarArtwork[];
  onArtworkClick?: (artwork: SimilarArtwork) => void;
}

export default function SimilarArtworksGrid({ artworks, onArtworkClick }: SimilarArtworksGridProps) {
  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-2xl font-display font-semibold mb-2 text-[#222222] dark:text-white">Similar Artworks</h3>
        <p className="text-sm text-[#666666] dark:text-gray-400 font-light">
          Discover works with similar style, color palette, and emotional tone
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {artworks.map((artwork) => (
          <Card
            key={artwork.id}
            className="overflow-hidden cursor-pointer transition-all duration-300 hover:shadow-xl hover:scale-[1.02] bg-white/80 dark:bg-white/5 backdrop-blur-sm border-gray-200 dark:border-gray-800"
            onClick={() => onArtworkClick?.(artwork)}
            data-testid={`card-similar-${artwork.id}`}
          >
            <div className="aspect-square relative group">
              <img
                src={artwork.imageUrl}
                alt={artwork.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent opacity-0 group-hover:opacity-100 transition-all duration-300">
                <div className="absolute bottom-0 left-0 right-0 p-5 text-white">
                  <p className="font-display italic text-lg mb-1 font-medium">{artwork.title}</p>
                  <p className="text-sm opacity-90 font-light">{artwork.artist}</p>
                  <p className="text-xs mt-2 opacity-75 font-light">
                    {artwork.similarity}% similar
                  </p>
                </div>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
