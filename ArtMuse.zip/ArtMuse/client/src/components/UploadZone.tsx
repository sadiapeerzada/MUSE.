import { Upload, Image as ImageIcon } from "lucide-react";
import { useState, useRef } from "react";

interface UploadZoneProps {
  onImageSelect: (file: File, preview: string) => void;
}

export default function UploadZone({ onImageSelect }: UploadZoneProps) {
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const file = e.dataTransfer.files[0];
    if (file && file.type.startsWith("image/")) {
      processFile(file);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const processFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const preview = e.target?.result as string;
      onImageSelect(file, preview);
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-[60vh] px-6">
      <div className="text-center mb-12">
        <h1 className="text-5xl lg:text-6xl font-display font-bold tracking-tight mb-4 bg-gradient-to-r from-[#222222] to-[#666666] dark:from-white dark:to-gray-300 bg-clip-text text-transparent">
          Discover the story behind your artwork
        </h1>
        <p className="text-lg text-[#666666] dark:text-gray-400 max-w-2xl mx-auto font-light">
          Drop an image or click to upload
        </p>
      </div>

      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
        className={`
          w-full max-w-2xl border-2 border-dashed rounded-2xl p-16 
          transition-all duration-500 cursor-pointer
          backdrop-blur-sm
          ${isDragging 
            ? "border-primary bg-primary/10 shadow-lg scale-[1.02]" 
            : "border-gray-300 dark:border-gray-700 bg-white/60 dark:bg-white/5 hover:bg-white/80 dark:hover:bg-white/10 hover:border-primary/50"
          }
        `}
        data-testid="dropzone-upload"
      >
        <div className="flex flex-col items-center text-center space-y-6">
          {isDragging ? (
            <Upload className="h-20 w-20 text-primary animate-pulse" />
          ) : (
            <ImageIcon className="h-20 w-20 text-gray-400 dark:text-gray-600" strokeWidth={1.5} />
          )}
          
          <div>
            <p className="text-xl font-light text-[#222222] dark:text-white mb-2">
              Drop your artwork here
            </p>
            <p className="text-sm text-[#666666] dark:text-gray-400 font-light">
              or click to browse
            </p>
          </div>
          
          <p className="text-xs text-[#999999] dark:text-gray-500 font-light tracking-wide">
            Supports JPG, PNG, WEBP up to 10MB
          </p>
        </div>

        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={handleFileSelect}
          className="hidden"
          data-testid="input-file-upload"
        />
      </div>

      <div className="mt-12 flex gap-6 justify-center opacity-60">
        <div className="text-center">
          <div className="w-24 h-24 bg-muted rounded-md mb-2" />
          <p className="text-xs text-muted-foreground">Mona Lisa</p>
        </div>
        <div className="text-center">
          <div className="w-24 h-24 bg-muted rounded-md mb-2" />
          <p className="text-xs text-muted-foreground">Starry Night</p>
        </div>
        <div className="text-center">
          <div className="w-24 h-24 bg-muted rounded-md mb-2" />
          <p className="text-xs text-muted-foreground">The Scream</p>
        </div>
      </div>
    </div>
  );
}
