import { ZoomIn, ZoomOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";

interface ArtworkDisplayProps {
  imageUrl: string;
  title: string;
  artist: string;
}

export default function ArtworkDisplay({ imageUrl, title, artist }: ArtworkDisplayProps) {
  const [zoom, setZoom] = useState(100);

  const handleZoomIn = () => {
    setZoom((prev) => Math.min(prev + 25, 200));
  };

  const handleZoomOut = () => {
    setZoom((prev) => Math.max(prev - 25, 50));
  };

  return (
    <div className="h-full flex flex-col bg-white/40 dark:bg-black/20 backdrop-blur-sm border-r border-gray-200 dark:border-gray-800">
      <div className="flex-1 flex items-center justify-center p-12 overflow-auto">
        <div className="relative">
          <img
            src={imageUrl}
            alt={title}
            className="max-h-[70vh] w-auto object-contain rounded-lg shadow-2xl shadow-black/10 dark:shadow-black/40 transition-all duration-500"
            style={{ transform: `scale(${zoom / 100})` }}
            data-testid="img-artwork"
          />
        </div>
      </div>

      <div className="p-8 border-t border-gray-200 dark:border-gray-800 bg-white/60 dark:bg-black/20 backdrop-blur-sm">
        <h2 className="text-2xl font-display italic mb-1 text-[#222222] dark:text-white" data-testid="text-artwork-title">
          {title}
        </h2>
        <p className="text-lg font-display font-semibold text-[#666666] dark:text-gray-400" data-testid="text-artist-name">
          {artist}
        </p>

        <div className="flex gap-2 mt-6">
          <Button
            variant="ghost"
            size="sm"
            onClick={handleZoomOut}
            disabled={zoom <= 50}
            data-testid="button-zoom-out"
            className="rounded-full"
          >
            <ZoomOut className="h-4 w-4" strokeWidth={1.5} />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleZoomIn}
            disabled={zoom >= 200}
            data-testid="button-zoom-in"
            className="rounded-full"
          >
            <ZoomIn className="h-4 w-4" strokeWidth={1.5} />
          </Button>
          <span className="text-sm text-[#666666] dark:text-gray-400 flex items-center ml-2 font-light">
            {zoom}%
          </span>
        </div>
      </div>
    </div>
  );
}
