import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

interface ArtworkInfo {
  title: string;
  artist: string;
  year?: string;
  style?: string;
  medium?: string;
  artistBio?: string;
  historicalContext?: string;
  trivia?: string;
}

interface ArtworkInfoPanelProps {
  info: ArtworkInfo;
}

export default function ArtworkInfoPanel({ info }: ArtworkInfoPanelProps) {
  return (
    <div className="space-y-6">
      <Card className="bg-white/80 dark:bg-white/5 backdrop-blur-sm border-gray-200 dark:border-gray-800 shadow-sm">
        <CardHeader className="space-y-6 pb-6">
          <div>
            <CardTitle className="text-3xl font-display tracking-tight mb-3 text-[#222222] dark:text-white">
              {info.title}
            </CardTitle>
            <p className="text-xl font-display font-semibold text-[#666666] dark:text-gray-400">
              {info.artist}
            </p>
          </div>
          
          <div className="grid grid-cols-3 gap-6 pt-6 border-t border-gray-200 dark:border-gray-800">
            <div>
              <p className="text-xs text-[#999999] dark:text-gray-500 uppercase tracking-wider mb-2 font-light">Year</p>
              <p className="font-display font-medium text-[#222222] dark:text-white" data-testid="text-year">{info.year || "Unknown"}</p>
            </div>
            <div>
              <p className="text-xs text-[#999999] dark:text-gray-500 uppercase tracking-wider mb-2 font-light">Style</p>
              <Badge variant="secondary" className="font-display font-normal bg-primary/10 text-primary border-0" data-testid="badge-style">
                {info.style || "Unknown"}
              </Badge>
            </div>
            <div>
              <p className="text-xs text-[#999999] dark:text-gray-500 uppercase tracking-wider mb-2 font-light">Medium</p>
              <p className="font-display font-medium text-[#222222] dark:text-white" data-testid="text-medium">{info.medium || "Unknown"}</p>
            </div>
          </div>
        </CardHeader>

        <CardContent>
          <Accordion type="single" collapsible defaultValue="bio" className="w-full">
            <AccordionItem value="bio" className="border-gray-200 dark:border-gray-800">
              <AccordionTrigger className="font-display text-base font-medium text-[#222222] dark:text-white hover:no-underline">
                About the Artist
              </AccordionTrigger>
              <AccordionContent className="text-[#666666] dark:text-gray-400 leading-relaxed font-light text-[15px]">
                {info.artistBio}
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="context" className="border-gray-200 dark:border-gray-800">
              <AccordionTrigger className="font-display text-base font-medium text-[#222222] dark:text-white hover:no-underline">
                Historical Context
              </AccordionTrigger>
              <AccordionContent className="text-[#666666] dark:text-gray-400 leading-relaxed font-light text-[15px]">
                {info.historicalContext}
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="trivia" className="border-gray-200 dark:border-gray-800">
              <AccordionTrigger className="font-display text-base font-medium text-[#222222] dark:text-white hover:no-underline">
                Interesting Facts
              </AccordionTrigger>
              <AccordionContent className="text-[#666666] dark:text-gray-400 leading-relaxed font-light text-[15px]">
                {info.trivia}
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>
    </div>
  );
}
