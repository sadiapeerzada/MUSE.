import type { Express } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import axios from "axios";
import OpenAI from "openai";
import { artworkAnalysisSchema, chatMessageSchema, type SimilarArtwork } from "@shared/schema";
import fs from "fs";

const upload = multer({ dest: "uploads/" });

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// Helper: Fetch Wikipedia summary
async function fetchWikipediaSummary(title: string): Promise<string> {
  try {
    const response = await axios.get("https://en.wikipedia.org/w/api.php", {
      params: {
        action: "query",
        format: "json",
        prop: "extracts",
        exintro: true,
        explaintext: true,
        titles: title,
      },
      timeout: 10000,
    });

    const pages = response.data?.query?.pages;
    const page = Object.values(pages)[0] as any;
    return page?.extract || "";
  } catch (error) {
    console.error("Wikipedia API error:", error);
    return "";
  }
}

// Helper: Search Met Museum
async function searchMetMuseum(query: string): Promise<any> {
  try {
    const searchResponse = await axios.get(
      "https://collectionapi.metmuseum.org/public/collection/v1/search",
      {
        params: { q: query },
        timeout: 10000,
      }
    );

    const objectIDs = searchResponse.data?.objectIDs;
    if (!objectIDs || objectIDs.length === 0) {
      return null;
    }

    const objectResponse = await axios.get(
      `https://collectionapi.metmuseum.org/public/collection/v1/objects/${objectIDs[0]}`,
      { timeout: 10000 }
    );

    return objectResponse.data;
  } catch (error) {
    console.error("Met Museum API error:", error);
    return null;
  }
}

// Helper: Get similar artworks from Met Museum
async function getSimilarArtworks(artistName: string, limit = 6): Promise<SimilarArtwork[]> {
  try {
    const searchResponse = await axios.get(
      "https://collectionapi.metmuseum.org/public/collection/v1/search",
      {
        params: { q: artistName },
        timeout: 10000,
      }
    );

    const objectIDs = searchResponse.data?.objectIDs?.slice(0, limit) || [];
    const artworks: SimilarArtwork[] = [];

    for (const id of objectIDs) {
      try {
        const objectResponse = await axios.get(
          `https://collectionapi.metmuseum.org/public/collection/v1/objects/${id}`,
          { timeout: 5000 }
        );

        const obj = objectResponse.data;
        if (obj.primaryImage && obj.title && obj.artistDisplayName) {
          artworks.push({
            id: id.toString(),
            title: obj.title,
            artist: obj.artistDisplayName,
            imageUrl: obj.primaryImage,
            similarity: Math.floor(Math.random() * 15) + 85, // Simulated similarity score
          });
        }
      } catch (error) {
        console.error(`Error fetching object ${id}:`, error);
      }
    }

    return artworks;
  } catch (error) {
    console.error("Met Museum similar artworks error:", error);
    return [];
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Image analysis endpoint
  app.post("/api/analyze-image", upload.single("image"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No image file provided" });
      }

      const imagePath = req.file.path;
      const imageBuffer = fs.readFileSync(imagePath);
      const base64Image = imageBuffer.toString("base64");

      // Use OpenAI Vision API to analyze the image
      const visionResponse = await openai.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [
          {
            role: "user",
            content: [
              {
                type: "text",
                text: `You are an expert art historian. Analyze this artwork and provide detailed information in the following JSON format:
{
  "title": "artwork title",
  "artist": "artist name",
  "year": "year or period",
  "style": "art movement/style",
  "medium": "medium used",
  "artistBio": "brief artist biography (2-3 sentences)",
  "historicalContext": "historical context and significance (2-3 sentences)",
  "trivia": "interesting facts or trivia (2-3 sentences)"
}

If you cannot identify the exact artwork, make your best educated guess based on visual analysis of style, technique, and subject matter. Be specific and informative.`,
              },
              {
                type: "image_url",
                image_url: {
                  url: `data:image/jpeg;base64,${base64Image}`,
                },
              },
            ],
          },
        ],
        max_tokens: 1000,
      });

      const analysisText = visionResponse.choices[0]?.message?.content || "{}";
      
      // Extract JSON from the response (handle potential markdown code blocks)
      let artworkData;
      try {
        const jsonMatch = analysisText.match(/\{[\s\S]*\}/);
        artworkData = jsonMatch ? JSON.parse(jsonMatch[0]) : JSON.parse(analysisText);
      } catch (parseError) {
        console.error("Error parsing OpenAI response:", parseError);
        artworkData = {
          title: "Unknown Artwork",
          artist: "Unknown Artist",
          year: "",
          style: "",
          medium: "",
          artistBio: analysisText,
          historicalContext: "",
          trivia: "",
        };
      }

      // Validate with schema
      const validatedData = artworkAnalysisSchema.parse(artworkData);

      // Fetch additional data from Wikipedia and Met Museum
      const [wikiSummary, metData, similarArtworks] = await Promise.all([
        fetchWikipediaSummary(validatedData.artist),
        searchMetMuseum(validatedData.title),
        getSimilarArtworks(validatedData.artist),
      ]);

      // Enhance data with Wikipedia info if available
      if (wikiSummary && !validatedData.artistBio) {
        validatedData.artistBio = wikiSummary.slice(0, 500);
      }

      // Enhance with Met Museum data if available
      if (metData) {
        if (metData.objectDate && !validatedData.year) {
          validatedData.year = metData.objectDate;
        }
        if (metData.medium && !validatedData.medium) {
          validatedData.medium = metData.medium;
        }
        if (metData.primaryImage && !validatedData.imageUrl) {
          validatedData.imageUrl = metData.primaryImage;
        }
      }

      // Clean up uploaded file
      fs.unlinkSync(imagePath);

      res.json({
        analysis: validatedData,
        similarArtworks,
      });
    } catch (error) {
      console.error("Error analyzing image:", error);
      res.status(500).json({ error: "Failed to analyze image" });
    }
  });

  // Chat endpoint
  app.post("/api/ask-muse", async (req, res) => {
    try {
      const validatedData = chatMessageSchema.parse(req.body);

      const systemMessage = `You are MUSE, an elegant and knowledgeable AI art expert. You provide concise, insightful answers about art, artists, movements, techniques, and art history. Your tone is calm, sophisticated, and educational - like a museum curator sharing fascinating insights. Keep responses focused and informative, typically 2-4 sentences unless more detail is specifically requested.`;

      const userMessage = validatedData.artworkContext
        ? `Context: ${validatedData.artworkContext}\n\nQuestion: ${validatedData.prompt}`
        : validatedData.prompt;

      const completion = await openai.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: systemMessage },
          { role: "user", content: userMessage },
        ],
        max_tokens: 450,
        temperature: 0.7,
      });

      const answer = completion.choices[0]?.message?.content || "I apologize, but I couldn't generate a response.";

      res.json({ answer });
    } catch (error) {
      console.error("Error in chat:", error);
      res.status(500).json({ error: "Failed to get response from MUSE" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
