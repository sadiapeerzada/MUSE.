# ArtMuse Design Guidelines

## Design Approach
**Reference-Based Museum Aesthetic** inspired by premium cultural institutions (Met Museum, MoMA, Google Arts & Culture) combined with modern web patterns. The design should evoke the sophisticated elegance of a physical museum while embracing digital interactivity.

## Core Design Elements

### A. Color Palette

**Light Mode (Primary):**
- Background: 42 15% 96% (warm cream)
- Surface: 40 20% 98% (off-white canvas)
- Primary: 35 45% 55% (muted gold/bronze)
- Text Primary: 25 10% 20% (charcoal)
- Text Secondary: 25 8% 45% (medium gray)
- Accent: 20 35% 45% (terracotta for CTAs)
- Border: 30 10% 88% (subtle dividers)

**Dark Mode:**
- Background: 25 12% 12% (deep charcoal)
- Surface: 25 10% 18% (elevated charcoal)
- Primary: 35 50% 65% (lighter gold)
- Text Primary: 40 15% 92% (cream white)
- Text Secondary: 30 10% 70% (light gray)
- Accent: 20 40% 60% (warm terracotta)

### B. Typography

**Font Families:**
- Display/Headings: 'Playfair Display' (serif, elegant, museum-quality)
- Body/UI: 'Inter' (sans-serif, clean readability)
- Metadata: 'Cormorant Garamond' (serif, for artwork details)

**Hierarchy:**
- Hero Title: text-5xl to text-7xl, font-display
- Section Headings: text-3xl to text-4xl, font-display, tracking-tight
- Artwork Titles: text-2xl, font-metadata, italic
- Artist Names: text-xl, font-metadata, font-semibold
- Body: text-base, font-body, leading-relaxed
- Metadata: text-sm, font-metadata, tracking-wide

### C. Layout System

**Spacing Primitives:** Use Tailwind units of 2, 4, 6, 8, 12, 16, 20, 24 for consistent rhythm.

**Main Application Layout:**
- Split-screen design: 50/50 on desktop (lg:), stacked on mobile
- Left Panel: Artwork display with zoom capability, full-height
- Right Panel: Scrollable info + chat, max-height with internal scroll
- Container: max-w-screen-2xl, px-6 to px-12

**Section Spacing:**
- Component padding: p-6 to p-8
- Section gaps: space-y-8 to space-y-12
- Card spacing: p-6, rounded-lg

### D. Component Library

**Upload Interface:**
- Large dashed border dropzone (border-2 border-dashed)
- Centered icon (upload/image icon, size-16)
- Prominent upload text with subtitle
- Smooth hover state with background shift
- Preview thumbnail grid when image selected

**Artwork Display Panel:**
- Full-height image container with object-contain
- Subtle shadow and border treatment
- Zoom controls overlay (bottom-right corner)
- Image attribution in small text below

**Information Cards:**
- Cream/charcoal background with subtle border
- Header with artwork title in italic serif
- Artist name in bold serif
- Grid layout for metadata (Year, Style, Medium)
- Collapsible sections for biography and context
- Elegant dividers between sections

**Similar Artworks Grid:**
- 3-column grid on desktop (grid-cols-3 gap-6)
- 2-column on tablet, single on mobile
- Card with image thumbnail (aspect-square)
- Title overlay on hover with gradient backdrop
- Smooth scale transform on hover

**AI Chat Interface:**
- Fixed height chat container (h-96 to h-[32rem])
- Message bubbles: User (gold accent bg), AI (cream/charcoal bg)
- Input field with send button integrated
- Typing indicator with animated dots
- Scrollable message history with smooth auto-scroll

**Navigation:**
- Minimal top bar with logo left, mode toggle right
- Transparent background with backdrop-blur when scrolling
- Logo: Serif font "ArtMuse" with small museum icon

### E. Interactive Elements

**Buttons:**
- Primary: Gold/bronze background, charcoal text, rounded-md
- Secondary: Outline with gold border, transparent bg with blur when over images
- Icon buttons: Circular, subtle hover scale
- Upload CTA: Larger size (px-8 py-4), prominent placement

**Cards & Surfaces:**
- Subtle elevation with shadow-sm to shadow-md
- Rounded corners (rounded-lg)
- Border treatments using border color from palette
- Hover states with gentle lift (transform translate-y-[-2px])

**Animations:**
- Page transitions: Fade + subtle slide (duration-300)
- Image loading: Skeleton shimmer effect
- Chat messages: Slide-in from bottom (duration-200)
- Hover states: Scale 1.02, duration-200
- NO distracting scroll animations or parallax

## Images

**Hero Section Image:**
No large hero image. The app launches directly into the upload interface with a clean, minimal presentation. The focus is on functionality and artwork being uploaded.

**Artwork Images:**
- Central display: High-resolution artwork image from user upload
- Similar artworks: Thumbnail images (300x300px minimum)
- Artist portraits: Small circular avatars in biography section
- Placeholder: Elegant frame illustration for empty states

**Image Treatment:**
- Maintain artwork aspect ratios
- Subtle drop shadows for depth
- Border frame effect for displayed artwork (optional thin gold border)

## Layout Structure

**Upload State (Initial):**
- Centered dropzone occupying 60% of viewport height
- Welcome message above: "Discover the Story Behind Any Artwork"
- Subtitle explaining the app functionality
- Visual examples below in a carousel (3-4 famous paintings)

**Analysis State (Post-Upload):**
- Split-screen activated
- Left: Full artwork display with controls
- Right: Stacked sections (Info → Similar Works → Chat)
- Smooth transition between states (500ms fade)

**Responsive Behavior:**
- Desktop (lg:): Side-by-side 50/50 split
- Tablet (md:): Side-by-side 40/60 split  
- Mobile: Stacked, image top, info bottom with sticky navigation

## Key Design Principles

1. **Museum Quality**: Treat every artwork with respect through elegant presentation
2. **Breathing Room**: Generous whitespace, never cramped
3. **Typography Hierarchy**: Clear visual distinction between artwork details and UI elements
4. **Subtle Sophistication**: Refined over flashy, timeless over trendy
5. **Content First**: Let the artwork be the star, UI supports but doesn't compete