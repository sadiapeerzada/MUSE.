# ArtMuse - AI-Powered Art Curator & Guide

## Overview

ArtMuse is a full-stack AI-powered web application that serves as an intelligent art curator, historian, and guide. Users can upload images of artworks to receive detailed analysis, historical context, and engage in conversational AI dialogue about the pieces. The application combines computer vision, natural language processing, and museum-quality design to create an immersive digital art experience.

**Core Capabilities:**
- Image upload and artwork recognition
- Detailed artwork information display (title, artist, year, style, medium)
- Artist biographies and historical context
- Similar artwork recommendations
- Interactive AI chat assistant for artwork discussion
- Museum-inspired aesthetic with dark/light theme support

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Technology Stack:**
- **Framework:** React with TypeScript
- **Build Tool:** Vite for fast development and optimized production builds
- **Routing:** Wouter (lightweight client-side routing)
- **State Management:** TanStack Query (React Query) for server state
- **UI Framework:** Radix UI primitives with shadcn/ui component system
- **Styling:** Tailwind CSS with custom design tokens

**Design System:**
- Museum-quality aesthetic inspired by Met Museum, MoMA, and Google Arts & Culture
- Custom typography: Playfair Display (headings), Inter (body), Cormorant Garamond (metadata)
- Split-screen layout: 50/50 artwork display and information panel on desktop, stacked on mobile
- Comprehensive light/dark theme support with custom HSL color variables
- Responsive design with mobile-first approach

**Component Architecture:**
- Modular component structure with clear separation of concerns
- Reusable UI components in `client/src/components/ui/`
- Feature components: `ArtworkDisplay`, `ArtworkInfoPanel`, `ChatInterface`, `SimilarArtworksGrid`, `UploadZone`
- Custom hooks for mobile detection and toast notifications

### Backend Architecture

**Technology Stack:**
- **Runtime:** Node.js with Express.js
- **Language:** TypeScript with ESM modules
- **Development:** tsx for TypeScript execution in development
- **Production:** esbuild for bundling

**API Design:**
- RESTful endpoints with `/api` prefix
- File upload handling via Multer middleware
- Server-side rendering setup for Vite in development
- Custom request/response logging middleware

**Route Structure:**
- `/api/analyze-image` - POST endpoint for artwork analysis
- `/api/chat` - POST endpoint for AI chat interactions

### Data Architecture

**Database:**
- **ORM:** Drizzle ORM with PostgreSQL dialect
- **Connection:** Neon serverless PostgreSQL driver
- **Schema Location:** `shared/schema.ts` for type-safe sharing between client and server

**Storage Strategy:**
- In-memory storage implementation (`MemStorage`) for development/demo
- User management with username/password authentication schema
- Prepared for database migration with Drizzle Kit

**Data Models:**
- `users` table: id (UUID), username (unique), password
- Type-safe schemas using Zod for validation:
  - `artworkAnalysisSchema` - artwork metadata and analysis
  - `similarArtworkSchema` - related artwork recommendations
  - `chatMessageSchema` - chat interaction structure

### External Dependencies

**AI & Machine Learning Services:**
- **OpenAI API** - Powers the conversational AI chat feature for artwork discussion and analysis
- **Hugging Face Inference API** - Image captioning and classification using models like Salesforce/blip-image-captioning-base

**Data Sources:**
- **Wikipedia API** - Retrieves artist biographies and artwork summaries via MediaWiki API
- **Met Museum API** - Fetches official artwork metadata from The Metropolitan Museum of Art's public collection API (no authentication required)

**Development Tools:**
- **Replit Plugins** - Development banner, cartographer, and runtime error modal for enhanced Replit experience
- Session management with `connect-pg-simple` for PostgreSQL session storage

**Key Integration Points:**
- Image analysis pipeline: User upload → Hugging Face classification → OpenAI enrichment → Met Museum verification
- Chat context awareness: Maintains artwork context throughout conversation using OpenAI's chat completion API
- Museum data enrichment: Cross-references multiple sources (Wikipedia, Met Museum) for comprehensive artwork information

**Environment Configuration:**
- `OPENAI_API_KEY` - Required for AI chat functionality
- `HF_API_TOKEN` - Required for image recognition
- `DATABASE_URL` - PostgreSQL connection string for Drizzle ORM